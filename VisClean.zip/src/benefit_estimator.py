
class BenefitEstimator(object):
    def __init__(self):
        pass

    def local_benefit(self):
        pass

    def global_benefit(self):
        pass

    def rank_local_benefit(self):
        pass

    def rank_global_benefit(self):
        pass