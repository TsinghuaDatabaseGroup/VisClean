
class Inference:
    def __init__(self):
        pass

    def learn2rule(self):
        pass

    def get_rule_question(self):
        pass